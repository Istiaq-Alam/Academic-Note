
//Convert time Second to minutes
import java.util.Scanner;

public class DisplayTime {
    /**
     * Display time
     */
    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in)) {
            // Prompt the user for input
            System.out.print("Enter an integer for seconds: ");
            int seconds = input.nextInt();
            int minutes = seconds / 60; // Find minutes in seconds
            int remainingSeconds = seconds % 60; // Seconds remaining
            System.out.println(seconds + " seconds is " + minutes +
                    " minutes and " + remainingSeconds + " seconds");
        }
    }
}
