public class Assignment4 {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
    }
}
