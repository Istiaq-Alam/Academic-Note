
// Author: Istiak Alam
// Date: 08/05/23
// Class: CSE-20
// Email: istiaq05101005@student.ndub.edu.bd
// Assignment2 Solution
import java.util.Scanner;

public class Assignment2 {
    public static void main(String[] args) {
        double radius, circumference, area, volume;
        System.out.print("Radius?  ");
        Scanner scanner = new Scanner(System.in);
        radius = scanner.nextDouble();
        circumference = 2 * Math.PI * radius;
        System.out.println("The circumference is " + circumference);
        area = Math.PI * radius * radius;
        System.out.println("The area is " + area);
        volume = 4 / 3 * Math.PI * radius * radius * radius;
        System.out.println("The volume is " + volume);
        System.out.print("Mass?  ");
        double mass = scanner.nextDouble();
        System.out.println("The energy is " + mass * Math.pow(299792458, 2) + " joules");

    }
}
