// Assignment1
// Author: Istiak Alam
// Date: 08/05/23
// Class: CSE-20
// Email: istiaq05101005@student.ndub.edu.bd
public class Assignment1 {
    public static void main(String[] args) {
        System.out.println("Java programming is great!");
        System.out.println("Istiak Alam");
        System.out.println("Computer Science and Engineering");
        System.out.println(1234 * 2);
        System.out.println("05/09/2023");
        System.out.println("CSE1206: Object-Oriented Programming");
        System.out.println("I am in this class because I really enjoy this programming language.");

    }
}
