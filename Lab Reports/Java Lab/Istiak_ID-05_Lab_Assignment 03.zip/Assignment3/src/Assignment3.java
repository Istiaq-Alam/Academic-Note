import java.util.Scanner;

public class Assignment3 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        double gross_salary, interest_income, capital_gains;

        System.out.print("Salary:  ");
        gross_salary = sc.nextDouble();
        System.out.print("Exemptions:  ");
        int exemptions = sc.nextInt();
        System.out.print("Interest:  ");
        interest_income = sc.nextDouble();
        System.out.print("Gains:  ");
        capital_gains = sc.nextDouble();
        double total_income = gross_salary + interest_income + capital_gains - 5000.00;
        System.out.println("Total Income : " + total_income);
        if (exemptions > 6)
            exemptions = 6;
        double adjusted_income = total_income - (exemptions * 1500.00);
        System.out.println("Adjusted Income : " + adjusted_income);

    }
}
